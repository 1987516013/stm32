
#include "stm32f10x.h" //STM32ͷ�ļ�
#include "sys.h"
#include "delay.h"
#include "led.h"


int main (void)
{
	int t=1;
	int k,i;
	int MaxTime=1000;
	int flag=0;//flagΪ0ʱΪ�䰵��Ϊ1ʱΪ����
	RCC_Configuration(); //ʱ������
	LED_Init();
	while(1)
 {

	GPIO_SetBits(GPIOC,GPIO_Pin_13);
	delay_us(t);
	GPIO_ResetBits(GPIOC,GPIO_Pin_13);
	delay_us(MaxTime-t);
	t++;
	if(t==MaxTime)
		flag=1;

 if(flag==1)
 {
	 while(1)
	 {
		 t--;
		 GPIO_SetBits(GPIOC,GPIO_Pin_13);
		 delay_us(t);
		 GPIO_ResetBits(GPIOC,GPIO_Pin_13);
		 delay_us(MaxTime+1-t);
	 
		 if(t==1)
		 {
			 flag=0;
			 break;
		 }
	 }
 }
}
}




